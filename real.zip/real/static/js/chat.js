// static/js/chat.js
document.addEventListener('DOMContentLoaded', function() {
    // Socket.io
    const socket = io();
    let currentRoom = null;
    
    // DOM Elements
    const roomList = document.getElementById('room-list');
    const chatMessages = document.getElementById('chat-messages');
    const chatHeader = document.getElementById('chat-header');
    const messageForm = document.getElementById('message-form');
    const messageInput = document.getElementById('message-input');
    const sendBtn = document.getElementById('send-btn');
    const notificationContainer = document.getElementById('notification-container');
    const createRoomForm = document.getElementById('create-room-form');
    const roomTypeRadios = document.querySelectorAll('input[name="room_type"]');
    const passwordField = document.getElementById('password-field');
    const passwordModal = document.getElementById('password-modal');
    const closeModal = document.querySelector('.close-modal');
    const joinRoomForm = document.getElementById('join-room-form');
    const joinRoomId = document.getElementById('join-room-id');
    const roomPassword = document.getElementById('room-password');
    const modalRoomName = document.getElementById('modal-room-name');
    const modalError = document.getElementById('modal-error');
    
    // Functions
    function loadRooms() {
        fetch('/rooms')
            .then(response => response.json())
            .then(rooms => {
                roomList.innerHTML = '';
                rooms.forEach(room => {
                    const roomItem = document.createElement('li');
                    roomItem.className = 'room-item';
                    roomItem.dataset.id = room.id;
                    roomItem.dataset.private = room.is_private;
                    
                    // Create room content with icon
                    roomItem.innerHTML = `
                        <span>
                            <i class="fas ${room.is_private ? 'fa-lock' : 'fa-comments'} room-icon"></i>
                            ${room.name}
                        </span>
                    `;
                    
                    // Add active class if this is the current room
                    if (currentRoom && currentRoom.id === room.id) {
                        roomItem.classList.add('active');
                    }
                    
                    roomItem.addEventListener('click', () => handleRoomClick(room));
                    roomList.appendChild(roomItem);
                });
            });
    }
    
    function handleRoomClick(room) {
        // Check if room access
        fetch(`/check-room-access/${room.id}`)
            .then(response => response.json())
            .then(data => {
                if (data.has_access) {
                    joinChatRoom(room);
                } else if (data.is_private) {
                    // Show password modal
                    passwordModal.style.display = 'block';
                    joinRoomId.value = room.id;
                    modalRoomName.textContent = `Room: ${data.name}`;
                    modalError.style.display = 'none';
                    roomPassword.value = '';
                } else {
                    // Automatically try to join public room
                    fetch('/join-room', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify({ room_id: room.id })
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            joinChatRoom(room);
                        } else {
                            showNotification(data.message, 'error');
                        }
                    });
                }
            });
    }
    
    function joinChatRoom(room) {
        // Leave current room if any
        if (currentRoom) {
            socket.emit('leave', { room: currentRoom.id });
        }
        
        // Set current room
        currentRoom = room;
        
        // Update UI
        document.querySelectorAll('.room-item').forEach(item => {
            item.classList.remove('active');
            if (item.dataset.id == room.id) {
                item.classList.add('active');
            }
        });
        
        chatHeader.innerHTML = `
            <h2>
                <i class="fas ${room.is_private ? 'fa-lock' : 'fa-comments'} room-icon"></i>
                ${room.name}
            </h2>
        `;
        
        messageInput.disabled = false;
        sendBtn.disabled = false;
        chatMessages.innerHTML = '';
        
        // Join socket room
        socket.emit('join', { room: room.id });
        
        // Load messages
        loadMessages(room.id);
    }
    
    function loadMessages(roomId) {
        fetch(`/messages/${roomId}`)
            .then(response => response.json())
            .then(messages => {
                chatMessages.innerHTML = '';
                messages.forEach(message => {
                    appendMessage(message);
                });
                scrollToBottom();
            });
    }
    
    function appendMessage(message) {
        const messageElement = document.createElement('div');
        messageElement.className = `message ${message.is_own ? 'message-own' : 'message-other'}`;
        messageElement.dataset.id = message.id;
        
        let actionsHtml = '';
        if (message.is_own) {
            actionsHtml = `
                <div class="message-actions">
                    <button class="action-btn delete-btn" title="Delete" data-id="${message.id}">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            `;
        } else {
            actionsHtml = `
                <div class="message-actions">
                    <button class="action-btn block-btn" title="Block User" data-user="${message.user_id}">
                        <i class="fas fa-ban"></i>
                    </button>
                </div>
            `;
        }
        
        messageElement.innerHTML = `
            <div class="message-info">
                <span>${message.username}</span>
                ${actionsHtml}
            </div>
            <div class="message-content">${message.content}</div>
            <div class="message-time">${formatTime(message.created_at)}</div>
        `;
        
        chatMessages.appendChild(messageElement);
        
        // Add event listeners for actions
        if (message.is_own) {
            const deleteBtn = messageElement.querySelector('.delete-btn');
            deleteBtn.addEventListener('click', () => deleteMessage(message.id));
        } else {
            const blockBtn = messageElement.querySelector('.block-btn');
            blockBtn.addEventListener('click', () => blockUser(message.user_id, message.username));
        }
    }
    
    function appendStatusMessage(message) {
        const statusElement = document.createElement('div');
        statusElement.className = 'status-message';
        statusElement.textContent = message;
        chatMessages.appendChild(statusElement);
        scrollToBottom();
    }
    
    function formatTime(timestamp) {
        // Format timestamp to HH:MM
        const date = new Date(timestamp);
        const hours = date.getHours().toString().padStart(2, '0');
        const minutes = date.getMinutes().toString().padStart(2, '0');
        return `${hours}:${minutes}`;
    }
    
    function scrollToBottom() {
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }
    
    function deleteMessage(messageId) {
        fetch('/delete-message', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ message_id: messageId })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Remove message from DOM
                const messageElement = document.querySelector(`.message[data-id="${messageId}"]`);
                if (messageElement) {
                    messageElement.remove();
                }
                showNotification('Message deleted');
            }
        });
    }
    
    function blockUser(userId, username) {
        if (confirm(`Block messages from ${username}?`)) {
            fetch('/block-user', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ user_id: userId })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    showNotification(`Blocked messages from ${username}`);
                    // Reload messages to hide blocked user's messages
                    loadMessages(currentRoom.id);
                }
            });
        }
    }
    
    function showNotification(message, type = 'success') {
        const notification = document.createElement('div');
        notification.className = `notification ${type === 'error' ? 'error' : ''}`;
        notification.textContent = message;
        notificationContainer.appendChild(notification);
        
        // Remove notification after animation completes
        setTimeout(() => {
            notification.remove();
        }, 4000);
    }
    
    // Event Listeners
    messageForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const message = messageInput.value.trim();
        if (!message || !currentRoom) return;
        
        socket.emit('message', {
            room: currentRoom.id,
            message: message
        });
        
        messageInput.value = '';
    });
    
    // Toggle password field visibility based on room type selection
    roomTypeRadios.forEach(radio => {
        radio.addEventListener('change', function() {
            if (this.value === 'private') {
                passwordField.classList.remove('hidden');
            } else {
                passwordField.classList.add('hidden');
            }
        });
    });
    
    // Close modal when clicking the X
    closeModal.addEventListener('click', function() {
        passwordModal.style.display = 'none';
    });
    
    // Close modal when clicking outside
    window.addEventListener('click', function(event) {
        if (event.target === passwordModal) {
            passwordModal.style.display = 'none';
        }
    });
    
    // Join private room form submission
    joinRoomForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const roomId = joinRoomId.value;
        const password = roomPassword.value;
        
        fetch('/join-room', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                room_id: roomId,
                password: password
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                passwordModal.style.display = 'none';
                // Reload rooms and join the room
                loadRooms();
                handleRoomClick({id: roomId});
            } else {
                // Show error message
                modalError.textContent = data.message;
                modalError.style.display = 'block';
            }
        });
    });
    
    // Socket events
    socket.on('connect', () => {
        console.log('Connected to server');
    });
    
    socket.on('message', (data) => {
        appendMessage(data);
        scrollToBottom();
    });
    
    socket.on('status', (data) => {
        appendStatusMessage(data.msg);
    });
    
    // Initial load
    loadRooms();
});